package model;
import model.*;
import java.util.*;
import view.*;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.*;


public class DisplayAnalysisString 
{
	 @FXML
	   public void analyseString(ActionEvent event) throws IOException {
			FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../view/StringAnalysis.fxml"));
		    Parent root2 = (Parent) fxmlLoader.load();
		    Stage stage = new Stage();
		    stage.initModality(Modality.APPLICATION_MODAL);
		    stage.setTitle("ABC");
		    stage.setScene(new Scene(root2));  
		    stage.show();
		    
		   
	   }
}
