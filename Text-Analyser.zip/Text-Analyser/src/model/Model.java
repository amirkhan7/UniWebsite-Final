package model;

import java.util.*;
import org.apache.commons.math3.distribution.TDistribution;
import org.apache.commons.math3.stat.correlation.SpearmansCorrelation;

public class Model {
	
	   
	   
	   public static int getWordCount(String s) {
		   
		   return s.length();
		   
	   }
	   
	   
	   public static String getWordFrequency(String s) {
		   
		   HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		    for (int i = 0; i < s.length(); i++) 
		    {
		    	char c = s.charAt(i);
		        Integer val = map.get(c);
		        if (val != null && c != ' ') 
		        {
		        map.put(c, new Integer(val + 1));
		        }else{
		        	map.put(c, 1);
		        }
		    }
		    	System.out.println(map);
		    	
		    	return s;
	 }
	   
	   
	   //This technically p same functionality as above 
	   public static String getRelativeFrequency(String s) {
		   
		   Map<String, Integer> storeCharCount = new HashMap<String, Integer>();


	        for (int x=0; x <s.length(); x++)
	        {
	            char getChar = s.charAt(x);
	            String convGetChar = Character.toString(getChar);
	            Integer countChar = storeCharCount.get(convGetChar);
	            storeCharCount.put(convGetChar, (countChar==null?countChar=1:countChar+1));

	        }
	        double RelFrequency = 0;
	        String output = null;
	        for (Map.Entry<String, Integer> getValue: storeCharCount.entrySet())
	        {
	            RelFrequency = (double)(getValue.getValue())/(s.length());
	            output = "Character "+getValue.getKey() +"  Relative Frequency: "+RelFrequency;

	        }
		   
		   return output; 
	   }
	   
	   
		   
}


