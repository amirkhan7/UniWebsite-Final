package controller;
import model.*;
import java.util.*;
import view.*;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.*;

public class Controller {

    @FXML private TextField getStringValue;
    
    @FXML private TextField postStringValue;


    private Model model = new Model();
    
    @FXML
    public void openWindow(ActionEvent event){
    	
    try {
    	
	   	FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("../view/EnterString.fxml"));
	    Parent root1 = (Parent) fxmlLoader.load();
	    Stage stage = new Stage();
	    stage.initModality(Modality.APPLICATION_MODAL);
	    stage.setTitle("ABC");
	    stage.setScene(new Scene(root1));  
	    stage.show();
    }catch(Exception ex) {
    	System.out.println("Failed to open window");
    }
   }
    
   @FXML
   public void switchWindow(ActionEvent event) throws IOException {
			
	   DisplayAnalysisString.analyseString();
	   
   }
    
    @FXML
    private void getCharacterAmount(ActionEvent event) {
    	
    	String t = model.getWordFrequency("dfkdfdkfjdklfj");
    	
    }
    
    
   @FXML 
   private void getRelativeFrequency(ActionEvent event) {
	   
	   String t = model.getRelativeFrequency("sdasdsadsadsadsa");
	   
	   
   }
   
   @FXML 
   private void getTextValue(ActionEvent event) 
   {
	   String val = getStringValue.getText();
	   String t = Model.getRelativeFrequency(val);
	   String x = Model.getWordFrequency(val);
	   System.out.println(t);
	   System.out.println(x);
	   
	 
  }
}